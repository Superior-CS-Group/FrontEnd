import React from 'react'

const Estimates = () => {
    return (
        <div>
            Estimating
        </div>
    )
}

export default Estimates

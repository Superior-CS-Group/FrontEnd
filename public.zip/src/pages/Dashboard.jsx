import React, {useEffect} from 'react'



import { useSelector } from 'react-redux'



const Dashboard = () => {

    const themeReducer = useSelector(state => state.ThemeReducer.mode)

    return (
        <div>
           
           
        </div>
    )
}

export default Dashboard

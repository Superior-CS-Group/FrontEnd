import ThemeReducer from "./ThemeReducer"
import { combineReducers } from "redux"

const rootReducer = combineReducers({ThemeReducer})

export default rootReducer
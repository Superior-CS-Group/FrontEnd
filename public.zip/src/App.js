import "bootstrap/dist/css/bootstrap.min.css";
import "antd/dist/antd.css";
import "./App.css";
import { Routes, Route } from "react-router-dom";
import Auth from "./pages/auth.page";
import Home from "./pages/home.pages";
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/auth/*" element={<Auth />} />
        <Route path="/*" element={<Home />} />
      </Routes>
    </div>
  );
}

export default App;

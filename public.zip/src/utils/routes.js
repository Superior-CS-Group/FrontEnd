import Dashboard from "../components/home/dashboard.component";

const routes = [
  {
    path: "/dashboard",
    exact: true,
    name: "Dashboard",
    component: <Dashboard />,
  },

{
  path:"/customers"
}

];
export default routes;
